import java.util.*;
class MF_Structure {
	ArrayList<String> prod= new ArrayList<String>();
	ArrayList<Integer> quant= new ArrayList<Integer>();
	ArrayList<Integer> count_1_prod= new ArrayList<Integer>();
	ArrayList<Integer> count_2_prod= new ArrayList<Integer>();
	MF_Structure(){}
	int getSize() {
		return prod.size();
	}
}
