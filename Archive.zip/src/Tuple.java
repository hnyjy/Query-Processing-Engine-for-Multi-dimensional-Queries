class Tuple {
	int quant;
	String state;
	int month;
	int year;
	int day;
	String prod;
	String cust;
}
